<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<link rel="icon" href="CAPEmount.png"/>
</head>
<body>

<div class="container-fluid">
  <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
    <input class="custom-file-input" type="file" name="file">
    <label class="custom-file-label" for="customFile">Choose file</label>
    <br>
    <br>
    <input type="submit" class="btn btn-info button" style="text-align: center;">
  </form>
</div>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $file = array();
    array_push($file, $_POST["file"]);
    if (empty($file[0])) {
        echo "No file selected.";
    } else {
        $file_parts = pathinfo($file[0]);
        switch($file_parts["extension"])
        {
          case "txt":
          array_push($file, "true");
          break;

          case "":
          case NULL:
          break;
        }
        function death() {
          try { throw new Exception("Error Code: ", 120); } catch(Exception $e) { die($e->getMessage(). $e->getCode() . "."); }
        }
        if($file[1] == "true") {
          echo "Valid, reading.<br>";
          $file1 = fopen($file[0], "r") or death();
          while(!feof($file1)) {
            $line = fgets($file1);
            $line = str_replace("%startCMT% ",'
												function Write($wtwcmt) {echo $wtwcmt;}
												function UseJAVA($wtpijcmt, $wtpujscmt) {
												  echo "
														  <canvas data-processing-sources=". $wtpijcmt ."></canvas>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/processing.js/1.6.6/processing.min.js"></script>
                <script src=". $wtpujscmt ."></script>
														";
												}
												',$line);
            $line = str_replace("include",'try { throw new Exception("Unexpected '.'"include".'.'"); } catch(Exception $e) { echo $e->getMessage(); }',$line);
		        $line = str_replace("$",'try { throw new Exception("Unexpected '. '"$"' .'."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("var ",'$',$line);
            $line = str_replace("if(",'try { throw new Exception("Unexpected '. '"("' .' after statement."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("foreach(",'try { throw new Exception("Unexpected '. '"("' .' after statement."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("for(",'try { throw new Exception("Unexpected '. '"("' .' after statement."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("while(",'try { throw new Exception("Unexpected '. '"("' .' after statement."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("elseif(",'try { throw new Exception("Unexpected '. '"("' .' after statement."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("switch(",'try { throw new Exception("Unexpected '. '"("' .' after statement."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("if(",'try { throw new Exception("Unexpected '. '"("' .' after statement."); } catch(Exception $e) { echo $e->getMessage(); }',$line);
            $line = str_replace("if ",'if(',$line);
            $line = str_replace("elseif ",'elseif(',$line);
            $line = str_replace("foreach ",'foreach(',$line);
            $line = str_replace("for ",'for(',$line);
            $line = str_replace("while ",'while(',$line);
            $line = str_replace("func ",'function ',$line);
												$line = str_replace(":",')',$line);
												$line = str_replace("as",'mmm',$line);
												$line = str_replace("in",'as',$line);
												$line = str_replace("&colon",':',$line);
												$line = str_replace("",'',$line);
												$line = str_replace("[@",'array(',$line);
												$converted .= $line . "<br>";
          }
          fclose($file1);
        } else {
          echo "Invalid, please try a .txt file.";
        }
    }
				
				$file2 = fopen("run.php", "w") or die("Unable to open run.php.");
				fwrite($file2, '<html><head><link href="index.css" rel="stylesheet" type="text/css" /></head><body>');
				fwrite($file2, '<?php function Write($wtwcmt) {echo $wtwcmt;}
												function UseJAVA($wtpijcmt, $wtpujscmt) {
												  echo "
														  <canvas data-processing-sources='. $wtpijcmt .'></canvas>
                <script src=https://cdnjs.cloudflare.com/ajax/libs/processing.js/1.6.6/processing.min.js></script>
                <script src="'. $wtpujscmt .'"></script>
														";
												}' . "<br>");
				fwrite($file2, 'file_put_contents("index.css","");');
				fwrite($file2, $converted);
				fwrite($file2, "?>");
				fwrite($file2, "</body></html>");
    fclose($myfile);
}
?>

<script>
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>

</body>
</html>